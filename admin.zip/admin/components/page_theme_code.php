<?php
include('../components/headerlink.php');
?>

<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2 p-0">
                <?php include('../components/sidebar.php'); ?>
            </div>
            <div class="col-sm-10 p-0">
                <div class="content">
                    
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include('../components/footerlink.php');
?>