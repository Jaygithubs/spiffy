
<link rel="stylesheet" href="<?=ASSETS?>css/sidebar.css">

<div id="sidebar">
    <ul>
        <li>
            <a href="<?=ADMIN_URL?>pages/admin.php">Admin</a>
        </li>
        <li>
            <a href="<?=ADMIN_URL?>pages/add_products.php">Add Product</a>
        </li>
        <li>
            <a href="<?=ADMIN_URL?>pages/add_category.php">Add Category</a>
        </li>
        <li>
            <a href="<?=ADMIN_URL?>pages/products.php">All Products</a>
        </li>
    </ul>
</div>
